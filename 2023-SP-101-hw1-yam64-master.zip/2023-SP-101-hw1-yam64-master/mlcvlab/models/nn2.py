import numpy as np
from mlcvlab.nn.losses import l2, l2_grad, cross_entropy_grad
from mlcvlab.nn.basis import linear, linear_grad
from mlcvlab.nn.activations import relu, sigmoid, sigmoid_grad, relu_grad
from .base import Layer


class NN2():
    def __init__(self):
        self.layers = [
            Layer(None, relu), 
            Layer(None, sigmoid)]

    def nn2(self, x): 
        # TODO
        # First Layer
        A1=relu(np.dot(x,self.layers[0].W))
        #print("---------------First Layer-------------------")
        # Second Layer
        A2= sigmoid(np.dot(A1,self.layers[1].W))
        #print("---------------Second Layer-------------------")
        self.layers[1].activation= A2
        self.layers[0].activation= A1
        #print("---------------Forward Pass Done-------------------")
        return A2
        #raise NotImplementedError("NN2 model not implemented")

    def grad(self, x, y, W):
        # TODO
        #A1,A2 = self.nn2(x)
        y_pred = self.nn2(x)
        n = x.shape[0]
        # Compute the loss gradient
        grad_loss = l2_grad(y,y_pred)

        
        # Backpropagation through the second layer
        grad_A2 = grad_loss * sigmoid_grad(self.layers[1].activation)
        #print("---------------Grad_A2-------------------")
        grad_W2 = np.dot(grad_A2.T, self.layers[0].activation).T
        #print("---------------Grad_W2-------------------")
        #print(grad_A2.shape , " ", self.layers[1].W.shape)
        grad_A1 = np.dot(grad_A2, self.layers[1].W.T) * relu_grad(self.layers[0].activation)
        #print("---------------Grad_A1-------------------")
        # Backpropagation through the first layer
        grad_W1 = np.dot(grad_A1.T, x).T
        #print("---------------Grad_W1-------------------")
        
        #Update the weights
        self.layers[1].W -= grad_W2
        self.layers[0].W -= grad_W1
        #print("------------------exit grad--------------")
        #print(f"Max value of grad_W1: {np.max(grad_W1)}")
        #print(f"Min value of grad_W1: {np.min(grad_W1)}")
        return self.layers[0].W, self.layers[1].W
 

    def emp_loss_grad(self, train_X, train_y, W, layer):
        # Calculate the empirical loss gradient

        """Removed the for loop for faster running time and  make use of the numpy operations 
        that can perform forward and backward pass over the whole training data (60000 images)."""
        #d_w1, d_w2 = self.grad(train_X, train_y, W)
        #return  d_w1, d_w2
        n = train_X.shape[0]
        #d_w1 = np.zeros_like(self.layers[0].W)
        #d_w2 = np.zeros_like(self.layers[1].W)
        #for i in range(n):
            #x = train_X[i:i+1]
            #y = train_y[i:i+1]
            # Compute the gradient for this example
        d_w1, d_w2 = self.grad(train_X, train_y, W)
        #d_w1 += d_w1
        #d_w2 += d_w2
        # Divide by the number of examples to get the average gradient
        d_w1 /= n
        d_w2 /= n
        #print("d_W1 from emp", d_w1)
        self.layers[1].W =d_w2
        self.layers[0].W =d_w1
        # Return the updated weights
        return self.layers[0].W, self.layers[1].W

        # return emp_loss_grad_
        #raise NotImplementedError("NN2 Emperical Loss grad not implemented")"""