# No additional 3rd party external libraries are allowed
import numpy as np
from numpy.linalg import norm # what should I use this for

def l2(y, y_hat):
    # TODO
    return np.sqrt(np.sum(np.square(y-y_hat)))
    #raise NotImplementedError("l2 loss function not implemented")

def l2_grad(y, y_hat):
    # TODO
    denom = l2(y, y_hat)
    if np.isnan(denom) or np.isclose(denom, 0):
        return np.nan
    return 1/denom * (y-y_hat)
    #raise NotImplementedError("Gradiant of l2 loss function not implemented")

def cross_entropy(y, y_hat): #why this was A and y
    # TODO
    return - y * np.log(y_hat)-(1-y)*np.log(1-y_hat)
    #raise NotImplementedError("Cross entropy loss function not implemented")
    
def cross_entropy_grad(y, y_hat):
    # TODO
    """add a small constant value (1e-9) to both
    the numerator and denominator of the fraction to avoid division by zero."""
    return ((1 - y) / (1 - y_hat + 1e-9)) - (y / (y_hat + 1e-9))
    #raise NotImplementedError("Gradiant of Cross entropy loss function not implemented")
    