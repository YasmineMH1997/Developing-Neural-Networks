# No additional 3rd party external libraries are allowed
import numpy as np

def relu(x):
    # TODO
    return np.maximum(0, x)
    #raise NotImplementedError("ReLU function not implemented")

def relu_grad(z):
    return np.where(z <= 0, 0, 1)
    #raise NotImplementedError("Gradient of ReLU function not implemented")

def sigmoid(x):
    # TODO
    """Numerically stable sigmoid function to avoids computing the 
    exponential of a large or small negative value and avoid overflow warning"""
    pos_mask = (x >= 0)
    neg_mask = (x < 0)
    z = np.zeros_like(x)
    z[pos_mask] = np.exp(-x[pos_mask])
    z[neg_mask] = np.exp(x[neg_mask])
    top = np.ones_like(x)
    top[neg_mask] = z[neg_mask]
    return top / (1 + z)
    #raise NotImplementedError("Sigmoid function not implemented")
    
def sigmoid_grad(z):
    # TODO
    return z * (1 - z)
    #raise NotImplementedError("Gradient of Sigmoid function not implemented")

def softmax(x):
    # TODO
    exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    #raise NotImplementedError("Softmax function not implemented")
    
def softmax_grad(z):
    # TODO
    s = z.reshape(-1,1)
    return np.diagflat(s) - np.dot(s, s.T)
    """grad = np.diag(z)

    for i in range(len(grad)):
        for j in range(len(grad)):
            if i == j:
                grad[i][j] = z[i] * (1 - z[i])
            else:
                grad[i][j] = -z[i] * z[j]

    return grad"""
    #raise NotImplementedError("Gradient of Softmax function not implemented")

def tanh(x):
    return (np.exp(x) - np.exp(-x)) / (np.exp(x) + np.exp(-x))
    #raise NotImplementedError("Tanh function not implemented")

def tanh_grad(z):
    # TODO
    return 1-np.square(tanh(z))
    #raise NotImplementedError("Gradient of Tanh function not implemented")
