import numpy as np


def SGD(model, train_X, train_y, lr, R):
    """
   .flat()  returns a 1-dimensional iterator over the array, which allows us to access individual elements in the flattened array instead of working with both rows and columns
    By calling .flat[j], we are accessing the jth element in the flattened array of weights, rather than the jth element in the original multi-dimensional array. 
    """
    grad = 0
    update_step = 0
    lr =0.001
    R= 100
    for i in range(R):
        # Identify one random parameter in W1 or W2
        np.random.seed(i)
        layer = np.random.randint(2)

        # Use W1
        j = np.random.randint(model.layers[layer].W.size) # Select a random weight index
        Wr_minus_1 = model.layers[layer].W.copy() # Create a copy of the weights
        # Zero-out all other weights, except the selected one j
        n, m = Wr_minus_1.shape


        # create a boolean mask to select all elements except the jth one
        mask = np.ones((n, m), dtype=bool)
        mask.flat[j] = False

        # zero-out all the elements except the jth one
        Wr_minus_1[mask] = 0
        #print("f",Wr_minus_1.flat[j])
       
       
        grad = model.emp_loss_grad(train_X, train_y,Wr_minus_1,None)
       
        update_step0 = lr * grad[0]
        update_step1 = lr * grad[1]
        model.layers[0].W += update_step0
        model.layers[1].W += update_step1
        lr = lr/1.02  #decaying learning rate over time to help SGD converge

        if i % 10 == 0:
            loss = np.mean(np.square(model.nn2(train_X) - train_y))
            print("Epoch {}: loss={}".format(i, loss))

    return model.layers[0].W, model.layers[1].W


   
   
   
    """ np.random.seed(42)
    for epoch in range(R):
        i = np.random.choice(2)
        # select a random weight cell from the i-th layer
        r, c = np.random.randint(model.layers[i].W.shape[0]), np.random.randint(model.layers[i].W.shape[1])
        w = model.layers[i].W[r, c]
        # compute the gradient for this weight cell
        d_w1, d_w2 = model.emp_loss_grad(train_X, train_y, w,None)
        # update the weight cell
        model.layers[i].W[r, c] -= lr * d_w1[r, c] if i == 0 else lr * d_w2[r, c]
        if epoch % 10 == 0:
            loss = np.mean(np.square(model.nn2(train_X) - train_y))
            print("Epoch {}: loss={}".format(epoch, loss))
    return model.layers[0].W, model.layers[1].W"""
